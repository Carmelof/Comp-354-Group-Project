TO-DO:
Domain Model
	- UML diagram
	
Main Use Cases
use case diagram to provide the context for the overall system, 
together with a description of the actors and the major use case.
	- Possible Use case thesis:
		Our program will provide a simple, and user firendly spreadsheet
		enviorment to store, and compute data.
	- Advanced (Iteration 2): Provide Sorting / graphs.

Main Use Cases breakdown:
	- IO system (New / Save / Open)
	- Formula System (Computation of formulas)
	- Data input (Formula or raw data)
