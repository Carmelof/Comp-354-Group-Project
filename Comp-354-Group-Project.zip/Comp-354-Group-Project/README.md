Comp-354-Group-Project
======================

Basically, excel.
So people shouldn't just use the editor on the site to do this?

Addison Rodomista - 1967568 <br />
Dragos Dinulescu - 6304826 <br />
Adrian Max McCrea - 9239057 <br />
Ghazal Zamani - 1971158 <br />
Carmelo Fragapane - 6298265 <br />
Long Wang - 9547967 <br />
Nicholas Constantinidis - 6330746 <br />
Asmaa Alshaibi -9738231

Documenter
Kevin Cameron - kevin.2008.cameron@gmail.com
