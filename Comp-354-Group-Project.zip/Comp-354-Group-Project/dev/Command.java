/********************************************** 
 * 											  *
 *           Author: Simone Ovilma  		  *	
 * 											  *			
 **********************************************/

package dev;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

public class Command {
	
/*******************************************************
 * Attributes						  
 *******************************************************/
	private String command;				
	private final String ALPHANUM_PATTERN = "^.*[A-Ja-j]\\d{1,2}.*$";
	
	
	
/*******************************************************
 * Constructors						 
 *******************************************************/
	public Command() {	
		
		command = "";	
	}
	
	public Command(String inputStr) {
		
		command = inputStr.toUpperCase();		
	}
	
	
/*******************************************************
 * Public methods						 
 *******************************************************/
	public void setCommand(String command) {		
			
		this.command = command.toUpperCase();				
	}
	
	public String getCommand() {
		
		return command;
	}
	
	public void trim() {
		
		command = command.replaceAll("\\s+", " ");
		command = command.replaceAll("^\\s+|\\s+$", "");
	}
		
	public boolean isValid() {
		return (isValidEquation() && isInRange());
	}
	
	public void updateGrid(Grid grid, String cellName) {
		Cell tmpCell;;
		double tmpValue =  0.0;
		
		for(int i = 0; i < grid.getRowCount(); i++) {
			for(int j = 0; j < grid.getColumnCount(); j++) {
				if(grid.getCell(i, j).getFormula().contains(cellName)) {
					tmpCell = new Cell(grid.getCell(i, j).getFormula(), i, j);
					tmpValue = grid.evaluteCell(tmpCell);
					tmpCell.setValue(tmpValue);
					grid.insertCell(tmpCell);					
				}
			}
		}
	}
			
	
/*******************************************************
 * Private methods	 -- Changed to public for test case use					 
 *******************************************************/
	public boolean isAlphaNumeric() {
		
		return (command.matches(ALPHANUM_PATTERN));
	}
	
	/*
	 * if equation = "A1 + 4 - 8 * C3", then replaceCellNamesByValue(equation, 1.0)
	 * returns "1.0 + 4 - 8 * 1.0"
	 */
	public String replaceCellNamesByValue(String equation, double value) {
	
		Pattern MY_PATTERN = Pattern.compile("[A-J]\\d{1,2}");
		Matcher myMatch = MY_PATTERN.matcher(equation);
		String myEquation = equation;
		
		while(myMatch.find()) {
			String cellName = myMatch.group();   
			myEquation = myEquation.replace(cellName, "" + value);			
		}  
		
		return myEquation;
	}
	
	public boolean isInRange(){
		
		Pattern MY_PATTERN = Pattern.compile("[A-J]\\d{1,2}");
		Matcher myMatch = MY_PATTERN.matcher(command);		
		
		while(myMatch.find()) {
			String cellName = myMatch.group();   
			int index = Integer.parseInt(cellName.substring(1));
			
			if(index > 10)
				return false;
		}  
				
		return true;
	}
	
	/*
	 * Check if the command is a valid equation by calling engine.eval
	 * if it's alphanumeric i.e. "E3 - 7 + C5" replace E3 and C5 by an arbitrary value
	 * if engine.eval catches an exception, then it means that it wasn't able to evaluate the expression,
	 * therefore the command is invalid
	 */
	public boolean isValidEquation() {
		ScriptEngineManager manager = new ScriptEngineManager();
	    ScriptEngine engine = manager.getEngineByName("JavaScript");
	    String numericEquation = command;
	    
	    if(isAlphaNumeric())
	    	numericEquation = replaceCellNamesByValue(command, 1.0);
	    
	    try {
			engine.eval(numericEquation);			
		} 	    
	    catch (ScriptException e) {		
			//e.printStackTrace();
	    	return false;
		}
	    		
		return true;				
	}
}
